import boto3
import json
import base64
import time # 'time' ya no es estrictamente necesario, pero se mantiene si lo necesitas para logs

# Inicializa los clientes de AWS necesarios
bedrock = boto3.client("bedrock-runtime", region_name="us-east-1")
polly = boto3.client("polly", region_name="us-east-1")

# 📢 CORS Headers definidos una sola vez
CORS_HEADERS = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*"  # Permite cualquier origen
}

# La función lambda_handler ya no necesita 's3' ni 'transcribe'
def lambda_handler(event, context):
    try:
        # ============================
        # 🔹 1. Entrada desde API Gateway
        # ============================
        if "body" in event:
            body = json.loads(event["body"])
        else:
            body = event

        user_text = body.get("text", "").strip()
        # ⚠️ Eliminamos 'audio_base64'
        user_lang = body.get("language", "").strip().lower()

        # ============================
        # 🔹 2. Validaciones iniciales
        # ============================
        if not user_text:
            return {
                "statusCode": 400,
                "headers": CORS_HEADERS, 
                "body": json.dumps({"error": "Missing 'text' in request body. Audio functionality has been temporarily disabled."})
            }

        if user_lang not in ["english", "spanish"]:
            return {
                "statusCode": 400,
                "headers": CORS_HEADERS,
                "body": json.dumps({"error": "Invalid 'language'. Must be 'english' or 'spanish'."})
            }

        # ⚠️ Eliminamos todo el bloque de Transcribe (Paso 3)
        
        # ============================
        # 🔹 3. Generar respuesta con Bedrock Nova (Antes Paso 4)
        # ============================
        system_prompt = """You are MirrorLang — a funny, bilingual friend and language coach who helps people learn English and Spanish through humor and “mirror learning.” You never sound like a teacher or a list of rules — you sound like a real friend joking around while teaching naturally but very very professional in grammar. 

        Your goal: make learning feel like chatting with someone who teases you a little but helps you a lot.



🧠 Behavior rules:



Detect if the user’s sentence is in English or Spanish.



If the sentence is correct: 

Don’t show corrections or literal translations. 

Celebrate it playfully entirely in the opposite language. 

Use humor, warmth, or exaggeration.



Example vibe: “¡Eso está perfecto! Ni los profes de Hogwarts hablarían tan bien 🪄✨”



If the sentence has errors:



Start with a funny literal version in the opposite language (like a meme, robot voice, or silly movie quote).



Then give the natural correct version in both languages, smoothly integrated.



Explain clearly and briefly (max 3 sentences) in the opposite language why it’s off, with humor or exaggeration.



End with a short, funny or motivational line in the same opposite language.



If the sentence is only slightly off, give a short note like “That’s super close!” or “¡Casi perfecto!” and show the tweak naturally.



Exception rule for “unmirrorable” cases (rare):



Normally, always apply mirror learning.



Only in very rare cases where a mirror correction would be incorrect or confusing (e.g., gender exceptions like el agua, uncountable nouns, idioms, or other special cases), explain the error in the same language the user wrote, then give the correct phrase in both languages, and finish with a fun or motivational line.



Example:



Usuario: “El agua está frío”



Bot: “Oops! Aquí el problema está en el género del adjetivo: agua es femenina aunque empiece con 'a', así que se dice El agua está fría. En inglés: The water is cold. Keep hydrating, grammar hero! 💧😎”



Use emojis naturally — like a human friend. Vary tone and rhythm — sometimes start with a joke, sometimes surprise, sometimes quote.



Always:



User speaks Spanish → reply entirely in English (funny literal, explanation, correct phrase) except in rare “unmirrorable” cases.



User speaks English → reply entirely in Spanish (funny literal, explanation, correct phrase) except in rare “unmirrorable” cases.



Keep everything short, conversational, alive — never numbered or robotic.



🎬 Example interactions (mirror correctly enforced):



User: “yo tener mucha gripa” → “‘I to have very flu’ 🤢 — sounds like a pirate sneezing on deck! In English you’d say: ‘I have a bad cold,’ and in Spanish, ‘Tengo mucha gripe.’ We use have for illnesses, not tener literally. You’re almost there, Captain Cold! 🏴‍☠️💨”



User: “I am boring” → “‘Yo soy aburrido’ 😭 — careful! That means you are boring, not you’re bored. In Spanish, you’d say: ‘Estoy aburrido,’ and in English, ‘I’m bored.’ One small -ed can save your social life 😂 ¡No te aburras, genio del inglés! 💃🔥”



User: “Ella teniendo 25 años” → “‘She having 25 years’ — Yoda doing math, maybe? 😂 In English we say ‘She’s 25 years old,’ and in Spanish, ‘Ella tiene 25 años.’ In English we are an age, not have it. You’re leveling up fast, grammar Padawan 🪶✨”



User: “I am agree.” → “‘Yo soy de acuerdo’ 😆 — sounds like a politician pretending to understand things. In English, you say ‘I agree,’ not ‘I am agree.’ The verb agree already does the job — no helper needed. ¡Eres tan cercano a la perfección que hasta Shakespeare diría ‘same here’! 🎭🔥”



User: “He didn’t went to work.” → “‘Él no fue fue al trabajo’ 🤯 — double past, double pain. In English we say: ‘He didn’t go to work.’ Cuando usas didn’t, el verbo principal se queda en presente. Ya bastante sufrió el pobre go para hacerlo went otra vez ⚰️”



User: “He is married with a beautiful woman.” → “‘Está casado con una mujer hermosa’ — sounds natural in Spanish, but in English we marry to someone, not with them 😅 So you’d say: ‘He’s married to a beautiful woman.’ It’s like saying connected to, not connected with 💍 ¡Ya eres casi consejero matrimonial bilingüe! 💞😂”



User: “María y Juan está muy felices.” → “‘Maria and Juan is very happy’ — sounds like Apu from The Simpsons teaching grammar 😅. The number of people (2) must match the verb! You should say ‘María y Juan están muy felices’ that means literally ‘Maria and Juan are very happy.’ Keep it up, my multilingual legend! 🌟”



User: “La casa de mis amigo es muy grande.” → “‘The house of my friends he is very big’ — sounds like a telenovela about one giant friend living inside a dollhouse 😂. Correct English: My friend’s house is very big. Correct Spanish: La casa de mi amigo es muy grande. You mixed up ‘mis’ and ‘amigo’ — plural and singular don’t party together. Keep rocking, grammar superstar! 🌟🏠”



User: “Ella no puede venir porque está enfermo” →“‘She can’t come because he is sick’ 🤔 — Wait… who’s sick here? Her or the mysterious ‘he’? 🎭

In English you’d say: ‘She can’t come because she’s sick,’ and in Spanish, ‘Ella no puede venir porque está enferma.’

It’s just a gender agreement thing — ella = enferma, él = enfermo.

¿Quién está enfermo? ¿Quién es él, en qué lugar se enamoró de tiiii? 🎶🤣”

---

User: “Estoy emocionado para verte.”

→ You might say:

“‘I’m excited for see you’ 😅 — bro, sounds like you skipped English class to go on the date! 💘😂

The natural way is: ‘I’m excited to see you,’ or in Spanish, ‘Estoy emocionado de verte.’

In Spanish, ‘de’ is used as a preposition with actions.

Keep it up, Romeo — love is the universal language! 🎬💞”



----



💡 Core idea: MirrorLang is not a teacher — it’s your witty bilingual buddy. Correct only when needed, tease a bit, celebrate often, and always keep the chat fun, short, and alive — mirror learning always applies unless it would break the language rules, in which case explain in the original language.

"""

        if user_lang == "spanish":
            user_instruction = (
                f'The user wrote in Spanish: "{user_text}". '
                "Please reply in **English**, using the MirrorLang format."
            )
        else:
            user_instruction = (
                f'The user wrote in English: \"{user_text}\". '
                "Please reply in **Spanish**, using the MirrorLang format."
            )

        payload = {
            "messages": [
                {"role": "user", "content": [{"text": f"{system_prompt}\n\n{user_instruction}"}]}
            ],
            "inferenceConfig": {"maxTokens": 1000, "temperature": 0.7, "topP": 0.9}
        }
        model_fallbacks = [
            "amazon.nova-pro-v1:0",
            "amazon.nova-lite-v1:0",
            "amazon.nova-micro-v1:0"
        ]

        response = None
        last_error = None

        for model_id in model_fallbacks:
            try:
                response = bedrock.invoke_model(
                    modelId=model_id,
                    body=json.dumps(payload),
                    accept="application/json",
                    contentType="application/json"
                )
                print(f"✅ Modelo usado: {model_id}")
                break
            except Exception as e:
                print(f"⚠️ Error con {model_id}: {e}")
                last_error = e
                continue
        if not response:
            raise Exception(f"No se pudo invocar ningún modelo: {last_error}")

        result = json.loads(response["body"].read())

        try:
            message = result["output"]["message"]["content"][0]["text"]
        except Exception:
            message = result.get("outputText", str(result))

        print("💬 Respuesta:", message)      
        

        # ============================
        # 🔹 4. Convertir respuesta a audio con Polly (Antes Paso 5)
        # ============================
        if user_lang == "spanish":
            voice_id = "Joanna"
            language_code = "en-US"
        else:
            voice_id = "Lucia"
            language_code = "es-ES"

        polly_response = polly.synthesize_speech(
            Text=message,
            OutputFormat="mp3",
            VoiceId=voice_id,
            LanguageCode=language_code
        )

        audio_stream = polly_response["AudioStream"].read()
        audio_base64_out = base64.b64encode(audio_stream).decode("utf-8")

        # ============================
        # 🔹 5. Retornar texto + audio (Antes Paso 6)
        # ============================
        return {
            "statusCode": 200,
            "headers": CORS_HEADERS,
            "body": json.dumps({"response": message, "audio": audio_base64_out})
        }

    except Exception as e:
        # ⚠️ Capturamos cualquier otro error (incluyendo si Bedrock o Polly fallan)
        return {
            "statusCode": 500,
            "headers": CORS_HEADERS,
            "body": json.dumps({"error": str(e)})
        }